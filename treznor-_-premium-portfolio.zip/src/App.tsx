/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from 'react';
import { 
  motion, 
  useScroll, 
  useTransform, 
  useSpring, 
  AnimatePresence,
  useInView
} from 'motion/react';
import { 
  ArrowRight, 
  Github, 
  Instagram, 
  Linkedin, 
  Mail, 
  Menu, 
  X, 
  ChevronDown, 
  Star,
  ExternalLink,
  Code2,
  Palette,
  Rocket,
  Search
} from 'lucide-react';

// --- Components ---

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'About', href: '#about' },
    { name: 'Skills', href: '#skills' },
    { name: 'Projects', href: '#projects' },
    { name: 'Process', href: '#process' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <nav className={`fixed top-0 w-full z-50 transition-all duration-500 ${scrolled ? 'glass py-4' : 'bg-transparent py-8'}`}>
      <div className="container mx-auto px-6 flex justify-between items-center">
        <motion.a 
          href="#" 
          className="text-2xl font-display font-bold tracking-tighter text-white"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
        >
          TREZNOR<span className="text-white/50">.</span>
        </motion.a>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center space-x-10">
          {navLinks.map((link, i) => (
            <motion.a
              key={link.name}
              href={link.href}
              className="text-sm font-medium text-text-secondary hover:text-white transition-colors"
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
            >
              {link.name}
            </motion.a>
          ))}
          <motion.button
            className="px-6 py-2 bg-white text-black text-sm font-bold rounded-full hover:bg-white/90 transition-all"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5 }}
          >
            Hire Me
          </motion.button>
        </div>

        {/* Mobile Toggle */}
        <button className="md:hidden text-white" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden glass border-t border-white/10 overflow-hidden"
          >
            <div className="flex flex-col p-6 space-y-6">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  className="text-xl font-display font-medium text-text-secondary hover:text-white"
                  onClick={() => setIsOpen(false)}
                >
                  {link.name}
                </a>
              ))}
              <button className="w-full py-4 bg-white text-black font-bold rounded-xl">
                Hire Me
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const Hero = () => {
  return (
    <section className="relative h-screen w-full flex items-center justify-center overflow-hidden bg-primary">
      {/* Animated Background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-white/5 rounded-full blur-[120px] animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-white/5 rounded-full blur-[120px] animate-pulse delay-1000" />
      </div>

      <div className="container mx-auto px-6 relative z-10 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
        >
          <motion.span 
            className="inline-block text-xs uppercase tracking-[0.4em] text-white/40 mb-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            Creative Web Developer
          </motion.span>
          <h1 className="text-5xl md:text-8xl font-display font-bold leading-[1.1] mb-8 max-w-5xl mx-auto">
            Crafting Digital Experiences That Feel Like <span className="text-glow">The Future</span>
          </h1>
          <p className="text-lg md:text-xl text-text-secondary max-w-2xl mx-auto mb-12 font-light">
            I design and develop modern, high-performance websites that elevate brands through cinematic storytelling and technical excellence.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
            <motion.button 
              className="group px-10 py-4 bg-white text-black font-bold rounded-full flex items-center gap-2 hover:scale-105 transition-transform"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              View Projects
              <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
            </motion.button>
            <motion.button 
              className="px-10 py-4 border border-white/20 text-white font-bold rounded-full hover:bg-white/5 transition-all"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Hire Me
            </motion.button>
          </div>
        </motion.div>
      </div>

      {/* 3D-ish Rotating Element */}
      <motion.div 
        className="absolute bottom-20 right-10 md:right-20 w-32 h-32 md:w-48 md:h-48 border border-white/10 rounded-2xl hidden lg:block"
        animate={{ 
          rotateY: 360,
          rotateX: 360,
          y: [0, -20, 0]
        }}
        transition={{ 
          duration: 20, 
          repeat: Infinity, 
          ease: "linear",
          y: { duration: 4, repeat: Infinity, ease: "easeInOut" }
        }}
        style={{ perspective: 1000 }}
      >
        <div className="w-full h-full glass rounded-2xl flex items-center justify-center">
          <Code2 size={48} className="text-white/20" />
        </div>
      </motion.div>

      {/* Scroll Indicator */}
      <motion.div 
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-40"
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <span className="text-[10px] uppercase tracking-widest">Scroll</span>
        <ChevronDown size={16} />
      </motion.div>
    </section>
  );
};

const About = () => {
  const stats = [
    { label: 'Projects Completed', value: '120+' },
    { label: 'Happy Clients', value: '85+' },
    { label: 'Years Learning', value: '8+' },
    { label: 'Tech Mastered', value: '25+' },
  ];

  return (
    <section id="about" className="py-32 bg-secondary relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-20 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl md:text-6xl font-bold mb-8">About TREZNOR</h2>
            <p className="text-xl text-text-secondary leading-relaxed mb-8 font-light">
              I am a digital architect specialized in building high-end web experiences. With a deep passion for UI/UX and technical performance, I bridge the gap between design and engineering.
            </p>
            <p className="text-lg text-text-secondary leading-relaxed mb-12">
              Every project I undertake is a journey into the future of the web. I don't just build websites; I create digital products that leave a lasting impression.
            </p>
            
            <div className="grid grid-cols-2 gap-6">
              {stats.map((stat, i) => (
                <motion.div 
                  key={stat.label}
                  className="glass p-6 rounded-2xl hover:bg-white/10 transition-colors group"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                >
                  <h3 className="text-3xl font-bold mb-1 group-hover:text-glow transition-all">{stat.value}</h3>
                  <p className="text-xs uppercase tracking-widest text-text-secondary">{stat.label}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>

          <motion.div 
            className="relative"
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
          >
            <div className="aspect-square glass rounded-3xl overflow-hidden relative group">
              <img 
                src="https://picsum.photos/seed/tech/800/800" 
                alt="Creative Workspace" 
                className="w-full h-full object-cover opacity-40 group-hover:scale-110 transition-transform duration-1000"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary to-transparent opacity-60" />
              
              {/* Floating Cards Overlay */}
              <motion.div 
                className="absolute top-10 -right-10 glass p-6 rounded-2xl hidden md:block"
                animate={{ y: [0, -20, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              >
                <Palette className="mb-4 text-white/60" />
                <p className="text-sm font-bold">UI/UX Design</p>
              </motion.div>
              
              <motion.div 
                className="absolute bottom-10 -left-10 glass p-6 rounded-2xl hidden md:block"
                animate={{ y: [0, 20, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut", delay: 1 }}
              >
                <Rocket className="mb-4 text-white/60" />
                <p className="text-sm font-bold">Performance</p>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

const Skills = () => {
  const skills = [
    { name: 'HTML', level: 95 },
    { name: 'CSS', level: 92 },
    { name: 'JavaScript', level: 90 },
    { name: 'React', level: 88 },
    { name: 'UI/UX Design', level: 85 },
    { name: 'GSAP Animations', level: 80 },
    { name: 'Three.js', level: 75 },
    { name: 'Web Performance', level: 90 },
  ];

  return (
    <section id="skills" className="py-32 bg-primary">
      <div className="container mx-auto px-6">
        <div className="text-center mb-20">
          <motion.h2 
            className="text-4xl md:text-6xl font-bold mb-6"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            Technical Arsenal
          </motion.h2>
          <p className="text-text-secondary max-w-2xl mx-auto">
            A curated selection of technologies I've mastered to build the next generation of web experiences.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {skills.map((skill, i) => (
            <motion.div
              key={skill.name}
              className="glass p-8 rounded-3xl group hover:glow transition-all duration-500"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              whileHover={{ y: -10 }}
            >
              <div className="flex justify-between items-end mb-6">
                <h3 className="text-lg font-bold">{skill.name}</h3>
                <span className="text-sm text-white/40">{skill.level}%</span>
              </div>
              <div className="h-1 w-full bg-white/10 rounded-full overflow-hidden">
                <motion.div 
                  className="h-full bg-white"
                  initial={{ width: 0 }}
                  whileInView={{ width: `${skill.level}%` }}
                  viewport={{ once: true }}
                  transition={{ duration: 1.5, ease: "circOut" }}
                />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Projects = () => {
  const projects = [
    {
      title: 'Lumina E-store',
      desc: 'A luxury fashion e-commerce experience with smooth transitions.',
      tags: ['React', 'Framer Motion', 'Stripe'],
      image: 'https://picsum.photos/seed/fashion/800/600',
      category: 'E-commerce'
    },
    {
      title: 'Zenith Watches',
      desc: 'High-end watch brand showcase with 3D product visualization.',
      tags: ['Three.js', 'GSAP', 'React'],
      image: 'https://picsum.photos/seed/watch/800/600',
      category: 'Luxury Brand'
    },
    {
      title: 'Aura Dining',
      desc: 'Interactive restaurant menu and reservation system.',
      tags: ['Next.js', 'Tailwind', 'Prisma'],
      image: 'https://picsum.photos/seed/food/800/600',
      category: 'Restaurant'
    },
    {
      title: 'Nova Studio',
      desc: 'Creative portfolio for a boutique design agency.',
      tags: ['React', 'Motion', 'WebGL'],
      image: 'https://picsum.photos/seed/studio/800/600',
      category: 'Portfolio'
    },
    {
      title: 'Flux SaaS',
      desc: 'Modern landing page for a futuristic AI startup.',
      tags: ['React', 'Tailwind', 'Vite'],
      image: 'https://picsum.photos/seed/startup/800/600',
      category: 'Startup'
    },
    {
      title: 'Nebula VR',
      desc: 'Immersive 3D landing page for a VR hardware company.',
      tags: ['Three.js', 'React Three Fiber'],
      image: 'https://picsum.photos/seed/vr/800/600',
      category: '3D Experience'
    }
  ];

  return (
    <section id="projects" className="py-32 bg-secondary">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-20 gap-8">
          <div>
            <h2 className="text-4xl md:text-6xl font-bold mb-6">Selected Works</h2>
            <p className="text-text-secondary max-w-xl">
              A collection of projects that define my commitment to quality and innovation.
            </p>
          </div>
          <button className="px-8 py-3 border border-white/20 rounded-full hover:bg-white text-black hover:text-black bg-transparent text-white transition-all font-bold">
            All Projects
          </button>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
          {projects.map((project, i) => (
            <motion.div
              key={project.title}
              className="group relative aspect-[4/5] rounded-3xl overflow-hidden glass"
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
            >
              <img 
                src={project.image} 
                alt={project.title} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />
              
              <div className="absolute inset-0 p-8 flex flex-col justify-end translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
                <span className="text-xs uppercase tracking-widest text-white/60 mb-2">{project.category}</span>
                <h3 className="text-2xl font-bold mb-3">{project.title}</h3>
                <p className="text-sm text-text-secondary mb-6 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                  {project.desc}
                </p>
                <div className="flex flex-wrap gap-2 mb-6 opacity-0 group-hover:opacity-100 transition-opacity duration-500 delay-100">
                  {project.tags.map(tag => (
                    <span key={tag} className="text-[10px] px-3 py-1 bg-white/10 rounded-full border border-white/10">{tag}</span>
                  ))}
                </div>
                <button className="flex items-center gap-2 text-sm font-bold group/btn">
                  View Project <ExternalLink size={14} className="group-hover/btn:translate-x-1 transition-transform" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const HorizontalShowcase = () => {
  const targetRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: targetRef,
  });

  const x = useTransform(scrollYProgress, [0, 1], ["0%", "-66.6%"]);

  const items = [
    { title: "INNOVATION", img: "https://picsum.photos/seed/innov/1200/800" },
    { title: "PRECISION", img: "https://picsum.photos/seed/prec/1200/800" },
    { title: "ELEGANCE", img: "https://picsum.photos/seed/eleg/1200/800" },
  ];

  return (
    <section ref={targetRef} className="relative h-[300vh] bg-primary">
      <div className="sticky top-0 h-screen flex items-center overflow-hidden">
        <motion.div style={{ x }} className="flex gap-20 px-20">
          {items.map((item, i) => (
            <div key={i} className="relative w-[80vw] md:w-[60vw] h-[60vh] flex-shrink-0">
              <div className="absolute -top-20 left-0">
                <h2 className="text-8xl md:text-[12rem] font-bold opacity-10 tracking-tighter leading-none">
                  {item.title}
                </h2>
              </div>
              <div className="w-full h-full rounded-3xl overflow-hidden glass">
                <img 
                  src={item.img} 
                  alt={item.title} 
                  className="w-full h-full object-cover opacity-60"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="absolute bottom-10 left-10">
                <p className="text-2xl font-display font-light max-w-md">
                  We push the boundaries of what's possible on the web, creating experiences that resonate.
                </p>
              </div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

const Testimonials = () => {
  const testimonials = [
    {
      name: 'Alexander Wright',
      company: 'Luxe Digital',
      review: 'TREZNOR transformed our brand vision into a digital masterpiece. The attention to detail is simply unparalleled.',
      avatar: 'https://i.pravatar.cc/150?u=alex'
    },
    {
      name: 'Sophia Chen',
      company: 'Nova Tech',
      review: 'Working with TREZNOR was a seamless experience. The performance and animations of our new site are world-class.',
      avatar: 'https://i.pravatar.cc/150?u=sophia'
    },
    {
      name: 'Marcus Thorne',
      company: 'Aura Studio',
      review: 'The futuristic design approach TREZNOR brings is exactly what we needed to stand out in a crowded market.',
      avatar: 'https://i.pravatar.cc/150?u=marcus'
    }
  ];

  const [active, setActive] = useState(0);

  return (
    <section className="py-32 bg-secondary overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="text-center mb-20">
          <h2 className="text-4xl md:text-6xl font-bold mb-6">Client Stories</h2>
          <div className="flex justify-center gap-1">
            {[1, 2, 3, 4, 5].map(i => <Star key={i} size={16} className="fill-white text-white" />)}
          </div>
        </div>

        <div className="max-w-4xl mx-auto relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={active}
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              className="glass p-12 md:p-20 rounded-[3rem] text-center"
            >
              <img 
                src={testimonials[active].avatar} 
                alt={testimonials[active].name} 
                className="w-24 h-24 rounded-full mx-auto mb-8 border-4 border-white/10"
              />
              <p className="text-2xl md:text-3xl font-light italic mb-10 leading-relaxed">
                "{testimonials[active].review}"
              </p>
              <h4 className="text-xl font-bold">{testimonials[active].name}</h4>
              <p className="text-text-secondary text-sm uppercase tracking-widest">{testimonials[active].company}</p>
            </motion.div>
          </AnimatePresence>

          <div className="flex justify-center gap-4 mt-12">
            {testimonials.map((_, i) => (
              <button
                key={i}
                onClick={() => setActive(i)}
                className={`w-3 h-3 rounded-full transition-all duration-500 ${active === i ? 'bg-white w-10' : 'bg-white/20'}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

const Process = () => {
  const steps = [
    {
      title: 'Discovery',
      desc: 'Deep diving into your brand vision, goals, and target audience to build a solid foundation.',
      icon: <Search size={32} />
    },
    {
      title: 'Design',
      desc: 'Crafting high-fidelity UI/UX concepts that blend luxury aesthetics with intuitive functionality.',
      icon: <Palette size={32} />
    },
    {
      title: 'Development',
      desc: 'Engineering fast, scalable, and interactive websites using cutting-edge technologies.',
      icon: <Code2 size={32} />
    },
    {
      title: 'Launch',
      desc: 'Rigorous testing and optimization to ensure a flawless delivery and a powerful market entry.',
      icon: <Rocket size={32} />
    }
  ];

  return (
    <section id="process" className="py-32 bg-primary">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl md:text-6xl font-bold mb-20 text-center">The Workflow</h2>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, i) => (
            <motion.div
              key={step.title}
              className="relative p-10 glass rounded-3xl group hover:bg-white/10 transition-all"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.2 }}
            >
              <div className="text-white/20 mb-8 group-hover:text-white transition-colors duration-500">
                {step.icon}
              </div>
              <span className="text-6xl font-bold absolute top-6 right-10 opacity-5 group-hover:opacity-10 transition-opacity">
                0{i + 1}
              </span>
              <h3 className="text-2xl font-bold mb-4">{step.title}</h3>
              <p className="text-text-secondary text-sm leading-relaxed">
                {step.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Contact = () => {
  return (
    <section id="contact" className="py-32 bg-secondary">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto glass rounded-[4rem] overflow-hidden grid lg:grid-cols-2">
          <div className="p-12 md:p-20 bg-white/5">
            <h2 className="text-4xl md:text-6xl font-bold mb-8 leading-tight">Let's Build Something Amazing</h2>
            <p className="text-text-secondary mb-12 text-lg">
              Ready to elevate your digital presence? Reach out and let's discuss how we can create a masterpiece together.
            </p>
            
            <div className="space-y-8">
              <div className="flex items-center gap-6">
                <div className="w-12 h-12 rounded-full glass flex items-center justify-center">
                  <Mail size={20} />
                </div>
                <div>
                  <p className="text-xs uppercase tracking-widest text-text-secondary">Email</p>
                  <p className="text-lg font-medium">hello@treznor.design</p>
                </div>
              </div>
              
              <div className="flex gap-4 pt-8">
                {[Github, Linkedin, Instagram].map((Icon, i) => (
                  <motion.a
                    key={i}
                    href="#"
                    className="w-12 h-12 rounded-full glass flex items-center justify-center hover:bg-white hover:text-black transition-all"
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    <Icon size={20} />
                  </motion.a>
                ))}
              </div>
            </div>
          </div>

          <div className="p-12 md:p-20">
            <form className="space-y-8">
              <div className="space-y-2">
                <label className="text-xs uppercase tracking-widest text-text-secondary">Name</label>
                <input 
                  type="text" 
                  className="w-full bg-transparent border-b border-white/20 py-4 outline-none focus:border-white transition-colors"
                  placeholder="John Doe"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs uppercase tracking-widest text-text-secondary">Email</label>
                <input 
                  type="email" 
                  className="w-full bg-transparent border-b border-white/20 py-4 outline-none focus:border-white transition-colors"
                  placeholder="john@example.com"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs uppercase tracking-widest text-text-secondary">Message</label>
                <textarea 
                  rows={4}
                  className="w-full bg-transparent border-b border-white/20 py-4 outline-none focus:border-white transition-colors resize-none"
                  placeholder="Tell me about your project..."
                />
              </div>
              <button className="w-full py-6 bg-white text-black font-bold rounded-2xl hover:bg-white/90 transition-all flex items-center justify-center gap-3 group">
                Send Message
                <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="py-20 bg-primary border-t border-white/5">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-center gap-10">
          <div className="text-center md:text-left">
            <h2 className="text-2xl font-display font-bold tracking-tighter mb-4">TREZNOR.</h2>
            <p className="text-text-secondary text-sm max-w-xs">
              Crafting premium digital experiences for forward-thinking brands.
            </p>
          </div>
          
          <div className="flex gap-10 text-sm font-medium text-text-secondary">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
          
          <div className="text-sm text-text-secondary">
            © 2026 TREZNOR. All rights reserved.
          </div>
        </div>
        
        <div className="mt-20 h-[1px] w-full bg-gradient-to-r from-transparent via-white/10 to-transparent" />
      </div>
    </footer>
  );
};

// --- Main App ---

export default function App() {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => setLoading(false), 2000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="relative">
      <AnimatePresence>
        {loading && (
          <motion.div
            className="fixed inset-0 z-[100] bg-primary flex items-center justify-center"
            exit={{ opacity: 0, scale: 1.1 }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          >
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center"
            >
              <h2 className="text-4xl font-display font-bold tracking-tighter mb-4">TREZNOR</h2>
              <div className="w-48 h-[2px] bg-white/10 rounded-full overflow-hidden">
                <motion.div 
                  className="h-full bg-white"
                  initial={{ width: 0 }}
                  animate={{ width: '100%' }}
                  transition={{ duration: 1.5, ease: "easeInOut" }}
                />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <Navbar />
      <main>
        <Hero />
        <About />
        <Skills />
        <Projects />
        <HorizontalShowcase />
        <Testimonials />
        <Process />
        <Contact />
      </main>
      <Footer />
      
      {/* Custom Cursor (Optional but adds premium feel) */}
      <div className="hidden lg:block">
        <CustomCursor />
      </div>
    </div>
  );
}

const CustomCursor = () => {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [isHovering, setIsHovering] = useState(false);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({ x: e.clientX, y: e.clientY });
    };

    const handleMouseOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target.closest('button, a, input, textarea')) {
        setIsHovering(true);
      } else {
        setIsHovering(false);
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseover', handleMouseOver);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseover', handleMouseOver);
    };
  }, []);

  return (
    <>
      <motion.div 
        className="fixed top-0 left-0 w-4 h-4 bg-white rounded-full pointer-events-none z-[9999] mix-blend-difference"
        animate={{ 
          x: mousePos.x - 8, 
          y: mousePos.y - 8,
          scale: isHovering ? 2.5 : 1
        }}
        transition={{ type: 'spring', damping: 30, stiffness: 250, mass: 0.5 }}
      />
      <motion.div 
        className="fixed top-0 left-0 w-10 h-10 border border-white/20 rounded-full pointer-events-none z-[9998]"
        animate={{ 
          x: mousePos.x - 20, 
          y: mousePos.y - 20,
          scale: isHovering ? 1.5 : 1,
          opacity: isHovering ? 0 : 1
        }}
        transition={{ type: 'spring', damping: 20, stiffness: 150, mass: 0.8 }}
      />
    </>
  );
};
